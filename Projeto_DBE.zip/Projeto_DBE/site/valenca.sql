create database Valença_Store;
use Valença_Store;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;
delete from usuario WHERE email = 'beamarques006@gmail.com'; 