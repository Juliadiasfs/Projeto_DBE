create database Valença_Store;
use Valença_Store;
create table usuario (
nome varchar(255),
email varchar(255) primary key,
senha varchar(255));
select * from usuario;
delete from usuario WHERE email = 'beamarques006@gmail.com'; 

CREATE TABLE produtos (
    id INT NOT NULL AUTO_INCREMENT, 
    tipo VARCHAR(45) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    descricao VARCHAR(90) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
    preco DECIMAL (10,2) NOT NULL, 
PRIMARY KEY (id));

drop table produtos;

select * from produtos;

INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violino', 'Violino Michael', 'Um instrumento de cordas com um corpo curvado e quatro cordas da marca Michael', 'Michael.png', '980.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violino', 'Violino Marinos Classic', 'Um instrumento de cordas com um corpo curvado e quatro cordas da marca Marinos', 'MarinosClassic.png', '500.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violino', 'Violino Le Messie', 'Um instrumento de cordas com um corpo curvado e quatro cordas da marca Le Messie', 'LeMesssie.png', '5000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violino', 'Violino Disney', 'Um instrumento de cordas com um corpo curvado e quatro cordas da marca Disney', 'ViolinoDisney.png', '150.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Saxofone', 'Saxofone Yamaha Yas62-04', 'Um instrumento de sopro com uma forma única geralmente feito de metal da marca Yamaha.', 'YAMAHASax.png', '25000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Saxofone', 'Saxofone Eagle Sa500 em Mib (eb)', 'Um instrumento de sopro com uma forma única geralmente feito de metal da marca Eagle.', 'Eagle.png', '5500.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Saxofone', 'Saxofone Halk Alto em Mib Preto com Douradas', 'Um instrumento de sopro com uma forma única geralmente feito de metal da marca Halk.', 'Halk.png', '3000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Saxofone', 'Saxofone Harmonics', 'Um instrumento de sopro com uma forma única geralmente feito de metal da marca Harmonics.', 'Harmonics.png', '3000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Piano', 'Piano Yamaha', 'Um instrumento com uma série de teclas brancas e pretas da marca Yamaha', 'YAMAHAPiano.png', '4000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Piano', 'Piano Digital Tokai', 'Um instrumento de teclas brancas e pretas da marca Tokai', 'TokaiPiano.png', '10000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Piano', 'Piano Samick', 'Um instrumento de teclas brancas e pretas da marca Samick', 'Samick.ong', '15000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Piano', 'Piano Albach', 'Um instrumento de teclas brancas e pretas da marca Albach', 'AlbachPiano.png', '2000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Flauta', 'Flauta Yamaha', 'Um instrumento de sopro de madeira ou metal da marca Yamaha', 'YAMAHAFlauta.png', '250.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Flauta', 'Flauta Germânia Dolphin', 'Um instrumento de sopro de madeira ou metal da marca Germânica Dolphin', 'GermânicaDolphin.png', '50.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Flauta', 'Flauta Nuova', 'Um instrumento de sopro de madeira ou metal da marca Nuova', 'Nuova.png', '1000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Flauta', 'Flauta Dizi', 'Um instrumento de sopro de madeira ou metal da marca Dizi', 'Dizi-flauta.png', '100.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violão', 'Violão Strinberg', 'Um instrumento geralmente com seis cordas semelhante à guitarra da marca Strinberg', 'Strinberg.png', '850.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violão', 'Violão Giannini', 'Um instrumento geralmente com seis cordas semelhante à guitarra da marca Giannini', 'Giannini.png', '400.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violão', 'Violão Ewacent', 'Um instrumento geralmente com seis cordas semelhante à guitarra da marca Ewacent', 'EWACENT.png', '950.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Violão', 'Violão Tagima', 'Um instrumento geralmente com seis cordas semelhante à guitarra da marca Tagima', 'TAGIMA.png', '550.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Ukulelê', 'Ukulelê Tagima', 'Um instrumento de cordas menor semelhante a um pequeno violão da marca Tagima', 'TagimaUk.png', '200.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Ukulelê', 'Ukulelê Andaluz', 'Um instrumento de cordas menor semelhante a um pequeno violão da marca Andaluz', 'Andaluz.png', '160.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Ukulelê', 'Ukulelê Seven', 'Um instrumento de cordas menor semelhante a um pequeno violão da marca Seven', 'Seven.png', '170.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Ukulelê', 'Ukulelê Shelby', 'Um instrumento de cordas menor semelhante a um pequeno violão da marca Shelby', 'Shelby.png', '200.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Guitarra', 'Guitarra Michael', 'Um instrumento geralmente com seis cordas com um corpo e um braço da marca Michael', 'MichaelG.png', '850.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Guitarra', 'Guitarra Fender', 'Um instrumento geralmente com seis cordas com um corpo e um braço da marca Fender', 'Fender.png', '2000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Guitarra', 'Guitarra Stratocaster', 'Um instrumento geralmente com seis cordas com um corpo e um braço da marca Stratocaster', 'Stratocaster.png', '1000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Guitarra', 'Guitarra Gibson', 'Um instrumento geralmente com seis cordas com um corpo e um braço da marca Gibson', 'Gibson.png', '1100.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Trompete', 'Trompete Michael', 'Um instrumento de sopro de metal com uma forma cônica e três válvulas da marca Michael', 'MichaelTr.png', '2200.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Trompete', 'Trompete Yamaha', 'Um instrumento de sopro de metal com uma forma cônica e três válvulas da marca Yamaha', 'YAMAHATr.png', '10000.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Trompete', 'Trompete Amw Custom', 'Um instrumento de sopro de metal com uma forma cônica e três válvulas da marca Amw Custom', 'AmwCustom.png', '1600.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Trompete', 'Trompete Andaluz', 'Um instrumento de sopro de metal com uma forma cônica e três válvulas da marca Andaluz', 'AndaluzTr.png', '1300.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Teclado', 'Teclado Meike', 'Um instrumento de teclas eletrônico que produz uma variedade de sons da marca Meike', 'Meike.png', '1100.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Teclado', 'Teclado Roland', 'Um instrumento de teclas eletrônico que produz uma variedade de sons da marca Roland', 'Roland.png', '1300.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Teclado', 'Teclado Tomshin', 'Um instrumento de teclas eletrônico que produz uma variedade de sons da marca Tomshin', 'Tomshin.png', '110.00');
INSERT INTO produtos (tipo, nome, descricao, imagem, preco) VALUES ('Teclado', 'Teclado Yamaha', 'Um instrumento de teclas eletrônico que produz uma variedade de sons da marca Yamaha', 'YAMAHATcl.png', '900.00');


update produtos set imagem = concat("images/",imagem);

