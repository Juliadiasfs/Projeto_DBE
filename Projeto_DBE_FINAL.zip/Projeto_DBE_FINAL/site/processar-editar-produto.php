<?php
require_once "conexao.php";

// ...
$nome = $_POST["nome"];
$tipo = $_POST["tipo"];
$descricao = $_POST["descricao"];
$preco = $_POST["preco"];
$id = $_POST["id"];
$imagem = $_FILES['imagem']['name'];

// Verifique se um arquivo de imagem foi enviado
//if (isset($imagem) && !empty($imagem)) {
if (isset($_FILES['imagem']['name']) && ($_FILES['imagem']['error'] == 0)) {
    $diretorio_destino = "images/"; // Pasta onde as imagens serão salvas
    $nome_arquivo = basename($_FILES["imagem"]["name"]); // Nome do arquivo enviado
    //$nome_arquivo = basename($imagem); // Nome do arquivo enviado
    $caminho_arquivo = $diretorio_destino . $nome_arquivo; // Caminho completo do arquivo no servidor
    $imagem = $caminho_arquivo;
    // Verifica se o arquivo é uma imagem
    $tipo_arquivo = strtolower(pathinfo($caminho_arquivo, PATHINFO_EXTENSION));
    $tipos_permitidos = array("jpg", "jpeg", "png", "gif");
    if (in_array($tipo_arquivo, $tipos_permitidos)) {
        // Tenta mover o arquivo temporário para o destino
        if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $caminho_arquivo)) {
            $sql = "UPDATE PRODUTOS SET nome = ?, tipo = ?, descricao = ?,
            preco = ?, imagem = ? WHERE id = ?";

            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sssdsi", $nome, $tipo, $descricao, $preco, $imagem, $id);

                if ($stmt->execute()) {
                    $stmt->close();
                    $conn->close();

                    header("Location: editar-produto-sucesso.php?teste=1&nome=$nome&tipo=$tipo&descricao=$descricao&preco=$preco&id=$id&imagem=$imagem&nomearquivo=$nome_arquivo");
                    exit();
                } else {
                    // A execução da consulta SQL falhou
                    $stmt->close();
                    $conn->close();
                    header("Location: editar-produto.php?erro=1&id=$id");
                    exit();
                }
            } else {
                // A preparação da consulta SQL falhou
                $conn->close();
                header("Location: editar-produto.php?erro=1&id=$id");
                exit();
            }
        } else {
            echo "Erro ao realizar o upload da imagem.";
        }
    } else {
        echo "Apenas arquivos do tipo JPG, JPEG, PNG e GIF são permitidos.";
    }
} else {


    $sql = "UPDATE PRODUTOS SET nome = ?, tipo = ?, descricao = ?,
         preco = ? WHERE id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("sssdi", $nome, $tipo, $descricao, $preco, $id);

        if ($stmt->execute()) {
            $stmt->close();
            $conn->close();

            header("Location: editar-produto-sucesso.php?teste=2&nome=$nome&tipo=$tipo&descricao=$descricao&preco=$preco&id=$id&imagem=$imagem");
            exit();
        } else {
            // A execução da consulta SQL falhou
            $stmt->close();
            $conn->close();

            header("Location: editar-produto.php?erro=1&id=$id");
            exit();
        }
    }
}
